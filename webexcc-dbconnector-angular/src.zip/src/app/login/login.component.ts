import { Component } from '@angular/core';
import { GlobalConstants } from '../global-constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  public myToken: any;

  constructor() {
    this.myToken = GlobalConstants.token;
  }



  login() {
    document.location.href = 'https://webexapis.com/v1/authorize?response_type=code&client_id=Cf71c589fe56180d158e155d504882357189ea33949c4e14bc8bfc46381df2a27&redirect_uri=http%3A%2F%2Flocalhost%3A4200&scope=cjp%3Aconfig_read&state=test';
  }

}
