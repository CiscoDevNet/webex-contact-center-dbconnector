export class GlobalConstants {
  public static isLoggedIn = false;
  public static token = { "access_token": "", "expires_in": "", "refresh_token": "", "refresh_token_expires_in": "", "token_type": "Bearer", "orginzationId": "", "scope": "" };
}
