import { Component } from '@angular/core';

@Component({
  selector: 'app-help123',
  templateUrl: './help123.component.html',
  styleUrls: ['./help123.component.css']
})
export class Help123Component {

}
